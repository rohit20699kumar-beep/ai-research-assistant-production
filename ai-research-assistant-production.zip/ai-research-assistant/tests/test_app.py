from fastapi.testclient import TestClient
from app import app
from core import normalize_database_url,assert_isolated_resource
from uuid import uuid4
def test_health(): assert TestClient(app).get('/health').json()['service']=='SourceForge Research AI'
def test_render_postgres_driver():assert normalize_database_url('postgresql://u:p@host/db').startswith('postgresql+psycopg://')
def test_evergreen_resource_guard():
 import pytest
 with pytest.raises(RuntimeError):assert_isolated_resource('postgresql://host/evergreen','database URL')
def test_private_history_requires_auth():assert TestClient(app).get('/api/research').status_code==401
def test_registration():
 r=TestClient(app).post('/api/register',json={'email':f"q{uuid4().hex}@example.com",'password':'StrongPass123!'})
 assert r.status_code==200 and r.json()['token']
