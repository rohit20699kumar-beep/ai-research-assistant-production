# SourceForge Research AI

Deployable research assistant with live Tavily web search, quick/standard/deep modes, source register, inline citation instructions, uncertainty and counterpoint analysis, persistent report library, account isolation and OpenAI-compatible synthesis.

## Run

1. Copy `.env.example` to `.env`; set `RESEARCH_APP_SECRET`, `RESEARCH_OPENAI_API_KEY`, and `RESEARCH_TAVILY_API_KEY`.
2. `docker build -t sourceforge-research .`
3. `docker run --env-file .env -p 8103:8103 sourceforge-research`
4. Open `http://localhost:8103` or `/docs`.

The report is grounded in retrieved excerpts and exposes every URL. Users should open and verify critical sources. For Render, use `render.yaml`. Production sellers should add billing quotas, scheduled retention, observability and domain/legal pages.
